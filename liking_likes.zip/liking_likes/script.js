var countElement = document.querySelector("#like_button1");
console.log(countElement);

function add1() {
    count.innerHTML++;
}

function add2() {
    count2.innerHTML++;
}

function add3() {
    count3.innerHTML++;
}
