console.log("page loaded...");

function play(video){
    video.play();
}

function pause(video){
    video.pause();
    }